# IMZYY KNOX GAME TURBO v4.1 — Premium Performance Suite

## Upgrade v4.0
- Refined dark premium interface and typography.
- FPS precision slider in the main app and floating hub; target is resolved to a refresh mode supported by the display.
- Floating hub uses a bounded scrollable panel with improved spacing.
- Render profiles: System Default, Compatibility, Performance. These are saved preferences only; they do not force another game's internal renderer.
- Smart toggles: frame-rate preference, thermal guard preference, battery balance, touch response preference, and saved game profile.
- Permission prompts for overlay, write system settings, and notifications are not repeatedly launched. If the user declines, the app shows a reminder rather than reopening Settings on every action.

## Honest Android limitations
A normal third-party app cannot force another game's internal FPS cap, switch its Vulkan/OpenGL renderer, overclock CPU/GPU, change governors, or modify touch sampling. FPS slider chooses a display refresh mode supported by the device. Some requested values are rounded to the nearest supported mode.

The thermal, battery, touch, and frame toggles are preference/profile switches and explanatory controls; they do not claim privileged hardware changes. Live sensor values remain sourced from Android APIs.


## Upgrade v4.1
- Added selectable display profiles: System Auto, Compatibility (lowest supported display mode), Balanced (nearest supported to 60 Hz), and Performance (highest supported display mode).
- Added APPLY DISPLAY PROFILE actions in the main screen and floating hub. If needed, the app opens Android's per-app **Modify system settings** permission screen. The user must approve it manually.
- Floating bubble and panel now reflow after portrait/landscape changes: bubble snaps to the nearest side and stays within the visible screen; panel width, height, and position are recalculated.
- This changes supported display refresh settings only. A regular app cannot force another game's internal renderer, GPU/CPU overclock, or graphics API.

## Upgrade v4.2 — Graphics Experience + Animated UI
- Added saved graphics presets: Smart Auto, Ultra Clarity, Balanced, Performance, and Thermal Safe.
- Added clear in-app guidance for texture, shadow, effects, resolution, and thermal choices.
- Added graphic profile controls to both the main app and floating hub.
- Added staggered screen entrance animations, subtle turbo-button breathing animation, and animated button feedback.
- Version bumped to 4.2.

### Graphics capability note
Android apps without privileged/root access cannot directly rewrite another game's texture quality, shader settings, internal resolution, Vulkan/OpenGL renderer, or GPU clocks. These presets save a profile, offer practical in-game recommendations, and can select a supported display refresh rate. They do not pretend to modify a game's private graphics engine.


## Upgrade v4.3 — Functional controls
- Frame Rate Optimization applies the highest supported display refresh mode and resets to system auto when disabled.
- Battery Balance lowers screen brightness and applies a 60 Hz-or-nearest display mode; it restores saved brightness when disabled. Requires Android Modify system settings permission.
- Thermal Guard blocks the app's RAM/cache boost action when battery temperature is at least 40°C. It does not cool the chipset or control CPU/GPU clocks.
- Touch Response opens Android Display settings so users can enable Samsung Touch sensitivity when exposed; the app cannot change touch sampling rate.
- Smart Game Profile is a real game picker with saved-game launch action.
- Graphics presets apply a supported display refresh mode; texture, shadows, shaders, internal resolution and GPU clocks remain controlled by the game/Android firmware.
- Floating Hub uses the same functional profile actions.

### Test notes
Source-level changes only. Build and device testing are still required. Permission-dependent features must be granted by the user in Android Settings.
